class Post
#  before_filter :authenticate_user!
 

 #'posts' => Array.new(' ' =>123, 'locations'=>Array.new(0=>Array.new('lat' =>'80.9900000', 'lng' =>'18.00000'), 1=> Array.new('lat' =>'99.9900000', 'lng' =>'19.00000'))),
  attr_accessor :locations,:comments, :title, :description, :likes, :shares
  def initialize(locations, comments, title, description, likes, shares)
    @locations=locations
    @comments= comments
    @title= title
    @description= description 
    @likes= likes
    @shares= shares
  end

  end