BackMongoid.Models.Post = Backbone.Model.extend({

});
