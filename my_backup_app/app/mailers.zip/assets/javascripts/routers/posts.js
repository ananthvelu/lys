BackMongoid.Routers.Posts = Backbone.Router.extend({

});
