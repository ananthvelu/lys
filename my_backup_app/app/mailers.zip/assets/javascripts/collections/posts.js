BackMongoid.Collections.Posts = Backbone.Collection.extend({

  model: BackMongoid.Models.Post

});
