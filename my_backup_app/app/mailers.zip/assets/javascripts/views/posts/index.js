BackMongoid.Views.PostsIndex = Backbone.View.extend({

  template: JST['posts/index']
  
});
