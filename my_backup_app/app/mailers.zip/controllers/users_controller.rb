class UsersController < ApplicationController
#  before_filter :authenticate_user!
respond_to :json  

  def index
    @users = User.all
  end

  def show

    #@user = User.find_by(uid: 123)
    @user =User.getDummyJSON()
   
    print "ANAND in show", @user#type
    logger.info("##########################")
    #logger.info(User.find())
    logger.info("My #{@user}")
  end
  def upsert

  end




#class
end	 

  
